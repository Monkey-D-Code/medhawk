const express = require('express');
const router = express.Router();


router.get('/',(req,res,next)=>{
    res.render('index',{
        title:'Welcome to Medhawk',
        activeHome : true,
    });
})
router.get('/about',(req,res,next)=>{
    res.render('about',{
        title:'About Us | Medhawk',
        activeAbout : true,
    });
})
router.get('/departments',(req,res,next)=>{
    res.send('departments');
})
router.get('/doctors',(req,res,next)=>{
    res.send('doctors');
})
router.get('/contact',(req,res,next)=>{
    res.render('contact',{
        title:'Contact Us | Medhawk',
        activeContact : true,
    });
})


module.exports = router;