const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
const hbs = require('express-handlebars');

// importing routes
const blogRoutes = require('./routes/blog');
const websiteRoutes = require('./routes/website');


const port = process.env.PORT || 8000;

const app = express();
app.use(bodyParser.urlencoded({extended:false}));

app.engine('hbs' , hbs({
    extname : 'hbs',
    
}));
app.set('view engine' , 'hbs');
app.use('/static',express.static(path.join(__dirname , 'public')));
app.set('views','views');

app.use('/' , websiteRoutes);
app.use('/blog',blogRoutes);


app.listen(port , ()=>{
    console.log(`Server running at ${port}`);
})